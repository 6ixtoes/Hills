def num (x, y):
    result = x + y
    return result   

num1 = int(input("type in a number:"))
num2 = int(input("type in a number:"))


result2 = num(num1, num2)
print(result2)